# dublin_postcode_shapefiles
This repository contains shapefiles of Dublin postcodes created by [Shane Mc Guinness](https://www.linkedin.com/in/shane-mc-guinness-ph-d-7290a817/) of Trinity College Dublin
